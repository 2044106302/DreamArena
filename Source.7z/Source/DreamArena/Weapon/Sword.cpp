// Fill out your copyright notice in the Description page of Project Settings.


#include "Sword.h"

ASword::ASword()
{

}






// 开始攻击并且进行检测
void ASword::StartAttack()
{

}
