// Fill out your copyright notice in the Description page of Project Settings.


#include "RoleAnim.h"

// Add default functionality here for any IRoleAnim functions that are not pure virtual.
