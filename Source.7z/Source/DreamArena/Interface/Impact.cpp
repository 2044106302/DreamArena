// Fill out your copyright notice in the Description page of Project Settings.


#include "Impact.h"

// Add default functionality here for any IImpact functions that are not pure virtual.
